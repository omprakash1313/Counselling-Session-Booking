# TalkFree : 
#### It is a counselling session booking web portal.
#### You can signup yourself as a counsellor or counselle.
### Features of Counselling Management System:
•	Scheduling the meeting between the counsellor and counselee as per the mode required by the counselee
•	Interviewing the counselee to identify his/her problem.
•	Giving the counselee suitable advice and guiding him/her.
To run the project :
1. Install XAMPP on your machine 
2. Go to the location where you have installed XAMPP 
3. Open XAMPP/htdocs and extract the zip file in this location
4. Open XAMPP and start Apache server and MySQL server
5. Go to your browser and type localhost/TalkFree in the serach bar
6. Open signup.php and create your account.

#### To use PHPMailer(Download files from here) :
https://github.com/PHPMailer/PHPMailer

#### For mailing we have used two service :
##### 1. PHPMailer
##### 2. MailJet

#### For creating meeting link we have used Zoom API.

# Relational Schema of TalkFree
![Relational Schema](Relational_Schema.png)
