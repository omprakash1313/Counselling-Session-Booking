<?php


$conn=mysqli_connect("localhost","root","","counselling") or die("The connection to the database has not been made");


?>